To run this assignment you need:

jupyter notebook
https://jupyter.org/

Dependencies:
    - python3
	All dependencies can be installed using pip.
    - Jupyter notebook
	https://jupyter.org/install
    - numpy
	https://pypi.org/project/numpy/
    - pytorch (cpu support is enough)
    https://pytorch.org/ 
    - gymnasium
    pip install gymnasium
    - matplotlib
    pip install matplotlib

The only file that should be modified is ps3.ipynb
