To run this assignment you need:

jupyter notebook
https://jupyter.org/

Dependencies:
    - python3
	All dependencies can be installed using pip.
    - Jupyter notebook
	https://jupyter.org/install
    - numpy
	https://pypi.org/project/numpy/
    - scipy
	https://pypi.org/project/scipy/
    - pygame
	https://pypi.org/project/pygame/
	- sklearn
	https://pypi.org/project/scikit-learn/
	pip install scikit-learn
	or with conda
	https://anaconda.org/anaconda/scikit-learn
	conda install -c anaconda scikit-learn
	- pandas
    https://pypi.org/project/pandas/
	pip install pandas
	or with conda
	https://pandas.pydata.org/docs/getting_started/install.html
    conda install pandas

The only file that should be modified is ps2.ipynb
